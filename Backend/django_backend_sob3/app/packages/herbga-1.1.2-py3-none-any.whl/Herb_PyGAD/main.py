import os
import time
import logging
import logging.handlers as handlers
from Herb_PyGAD.fitness.fitness import fitness_func
from Herb_PyGAD.crossover import custom_crossover
from Herb_PyGAD.mutation import custom_mutation
from Herb_PyGAD.dataSaver import file_exists, delete_file
from Herb_PyGAD.testData import filepath
from pygad import pygad


logger = logging.getLogger('py_gad')
logger.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')

try:
    os.makedirs("./herbGA_logs")
except FileExistsError:
    pass

logHandler = handlers.RotatingFileHandler('./herbGA_logs/pygad.log', maxBytes=1000000, backupCount=2)

logHandler.setLevel(logging.DEBUG)
logHandler.setFormatter(formatter)
logger.addHandler(logHandler)


if file_exists(filepath):
    delete_file(filepath)

locations = []
initial_population = []
skus = []
countries = {}
pickdata = {}
country_groups_for_area = []


def on_generation(ga_instance):
    logger.info(f"Generation = {ga_instance.generations_completed}")
    logger.info(f"Fitness    = {ga_instance.best_solution(pop_fitness=ga_instance.last_generation_fitness)[1]}")


def run_ga(initial_pop, skus_array, locations_array, countries_dict, pick_data_dict, country_groups_for_area_array):
    """
        Starts the genetic algorithm, calculates the runtime and prints the result

        :param list initial_pop: [[Int], [Int], ...] to start the genetic algorithm with a custom initial population on the first generation
        :param array skus_array: [] of all available skus. This array must have the same lenght as the locations array. Empty locations should be marked with -1.
        :param array locations_array: sorted [] of all slots in the warehouse. This array must have the same lenght as the SKU array because together these 2 arrays are a warehouse layout
        :param dict countries_dict: {} of all skus and its assigned countries
        :param dict pick_data_dict: {} of all skus and its calculated sum of picks per given timeframe
        :param array country_groups_for_area_dict: [[string], [string], ...] with 1 array of country codes for each group
    """
    global locations
    global initial_population
    global skus
    global countries
    global pickdata
    global country_groups_for_area

    initial_population = initial_pop
    skus = skus_array
    locations = locations_array
    countries = countries_dict
    pickdata = pick_data_dict
    country_groups_for_area = country_groups_for_area_array

    t1 = time.time()

    ga_instance = pygad.GA(initial_population=initial_population,
                           num_generations=1000,
                           num_parents_mating=9,
                           keep_elitism=3,
                           fitness_func=fitness_func,
                           crossover_type=custom_crossover,
                           mutation_type=custom_mutation,
                           on_generation=on_generation,
                           parallel_processing=None)

    ga_instance.run()

    solution, solution_fitness, solution_idx = ga_instance.best_solution()
    logger.info("Parameters of the best solution : {solution}".format(solution=solution))
    logger.info("Fitness value of the best solution = {solution_fitness}".format(solution_fitness=solution_fitness))

    t2 = time.time()
    print("Time is", t2-t1)

    # ga_instance.plot_fitness().savefig("gen_vs_fit-graph")

    delete_file(filepath)