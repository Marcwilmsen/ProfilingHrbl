import logging
import Herb_PyGAD.main
from Herb_PyGAD.dataSaver import save_file, file_exists, load_file
from Herb_PyGAD.testData import filepath

logger = logging.getLogger('py_gad')


# O(n)
def find_zone_start_end_indexes():
    if file_exists(filepath):
        return load_file(filepath)

    zone_Id_letter = []
    prev_value = ""
    count = 0
    indexes = []
    for i in Herb_PyGAD.main.locations:
        value = i[:2]
        if value != prev_value:
            zone_Id_letter.append(value)
            indexes.append(count)
            logger.info("value: {}".format(value))
            logger.info("prev value: {}".format(prev_value))
            
        prev_value = value
        count += 1



    save_file(filepath, indexes)
    logger.info("Indexes to save: {}".format(indexes))
    logger.info("Zonecutter count: {}".format(count))
    return indexes


# O(n x k)
def cut_solution_array_into_zones(solution):
    zones = []
    zone_index = find_zone_start_end_indexes()

    for index, start in enumerate(zone_index):
        if index < len(zone_index) - 1:
            zones.append(solution[start:zone_index[index + 1]])
        else:
            zones.append(solution[start:])

    logger.info("Cut solution array: {}".format(zones))
    logger.info("We have nr. zones: {}".format(len(zones)))
    return zones
