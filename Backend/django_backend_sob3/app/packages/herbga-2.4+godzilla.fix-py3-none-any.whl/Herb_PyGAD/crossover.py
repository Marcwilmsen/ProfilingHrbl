import logging
import random
import sys
from enum import Enum
from re import match
import numpy as np
from Herb_PyGAD.fitness.pickCounter import check_matching_strings
from Herb_PyGAD.fitness.zoneCutter import cut_solution_array_into_zones
import Herb_PyGAD.main as main

np.set_printoptions(threshold=sys.maxsize)
logger = logging.getLogger('py_gad')


# Big brain code energy gone


def custom_crossover_without_Constraints(parents, offspring_size, ga_instance):
    """
        The crossover uses the parent to randomly select two zones in the pareents array.
        Then the algorithm randomly selects the number of elements to cut
        The same amount of products are cut from the end of each zone (Done so because not every zone has the same length)
        The 4 cut zones are crossed
        Zone 1 -> Zone 1.1 + Zone 1.2
        Zone 2 -> Zone 2.1 + Zone 2.2

        Children
        newZone 1 -> Zone 1.2 + Zone 2.2
        newZone 2 -> Zone 2.1 + Zone 1.2

        NewParent contains the swapped zones and is added to the array of children that is returned at the end.


        Complexity:
        O(n)

        Parameters:
        - parents ([Int]): An Array of ints representing the id of the product. The parent array is randomly selected by the GA
        - offspring_size (tuple(Amount of children, length of each child)): Only the amount of children that should be produced are interesting in this method

        Returns:
        An array of children
    """
    offspring = []

    while len(offspring) < offspring_size[0]:

        logging.debug("Parent before crossover: {}".format(parents[len(offspring)]))
        zones = cut_solution_array_into_zones(parents[len(offspring)])

        random_zone_idx_1 = random.randint(0, len(zones) - 1)
        random_zone_idx_2 = random.randint(0, len(zones) - 1)
        random_zone_1 = zones[random_zone_idx_1]
        random_zone_2 = zones[random_zone_idx_2]

        logging.debug("Zone A (before crossover): {}".format(random_zone_1))
        logging.debug("Zone A (before crossover): {}".format(random_zone_2))

        number_of_elements_to_switch = random.randint(1, len(random_zone_1) - 1)
        if number_of_elements_to_switch < len(random_zone_1) and number_of_elements_to_switch < len(random_zone_2):
            start_1 = random_zone_1[:len(random_zone_1) - number_of_elements_to_switch]
            stop_1 = random_zone_1[len(random_zone_1) - number_of_elements_to_switch:]

            start_2 = random_zone_2[:len(random_zone_2) - number_of_elements_to_switch]
            stop_2 = random_zone_2[len(random_zone_2) - number_of_elements_to_switch:]

            zones[random_zone_idx_1] = np.concatenate((start_1, stop_2), axis=None)
            zones[random_zone_idx_2] = np.concatenate((start_2, stop_1), axis=None)

        logging.debug("Zone A (after crossover): {}".format(zones[random_zone_idx_1]))
        logging.debug("Zone B (after crossover): {}".format(zones[random_zone_idx_2]))
        newParent = np.concatenate(zones, axis=None)
        logging.debug("Edited parent after crossover: {}".format(newParent))

        offspring.append(newParent)
    return np.array(offspring)


def custom_crossover(parents, offspring_size, ga_instance):
    """
        The crossover uses the parent to randomly select two zones in the pareents array.
        Then the algorithm randomly selects the number of elements to cut
        The same amount of products are cut from the end of each zone (Done so because not every zone has the same length)
        The 4 cut zones are crossed
        Zone 1 -> Zone 1.1 + Zone 1.2
        Zone 2 -> Zone 2.1 + Zone 2.2

        Children
        newZone 1 -> Zone 1.2 + Zone 2.2
        newZone 2 -> Zone 2.1 + Zone 1.2

        NewParent contains the swapped zones and is added to the array of children that is returned at the end.


        Complexity:
        O(n)

        Parameters:
        - parents ([Int]): An Array of ints representing the id of the product. The parent array is randomly selected by the GA
        - offspring_size (tuple(Amount of children, length of each child)): Only the amount of children that should be produced are interesting in this method

        Returns:
        An array of children
    """
    offspring = []

    while len(offspring) < offspring_size[0]:
        logging.debug("Parent before crossover: {}".format(parents[len(offspring)]))
        solution_in_zones = cut_solution_array_into_zones(parents[len(offspring)])
        location_in_zones = cut_solution_array_into_zones(main.locations)

        random_zone_idx_1 = random.randint(0, len(solution_in_zones) - 1)
        random_zone_idx_2 = random.randint(0, len(solution_in_zones) - 1)
        random_zone_1 = solution_in_zones[random_zone_idx_1]
        random_zone_1_slots = location_in_zones[random_zone_idx_1]
        random_zone_2 = solution_in_zones[random_zone_idx_2]
        random_zone_2_slots = location_in_zones[random_zone_idx_2]

        logging.debug("Zone A (before crossover): {}".format(random_zone_1))
        logging.debug("Zone B (before crossover): {}".format(random_zone_2))

        number_of_elements_to_switch = int(min(len(random_zone_1), len(random_zone_2))/3)

        print("number_of_elements_to_switch: ", number_of_elements_to_switch)

        for i in range(1, number_of_elements_to_switch):
            random_zone_1 = solution_in_zones[random_zone_idx_1]
            random_zone_2 = solution_in_zones[random_zone_idx_2]

            random_index_product1 = random.randint(1, min(len(random_zone_1), len(random_zone_2)) - 1)
            random_index_product2 = random.randint(1, min(len(random_zone_1), len(random_zone_2)) - 1)
            zone_1, zone_2 = switch_products(random_zone_1, random_zone_2, random_index_product1, random_index_product2,
                                             random_zone_1_slots, random_zone_2_slots)
            print("Bevor")
            print("zone_1: ", zone_1)
            print("zone_2: ", zone_2)

            print("Bool: ", np.array_equal(random_zone_1, zone_1))
            print("Bool: ", np.array_equal(random_zone_2, zone_2))

            solution_in_zones[random_zone_idx_1] = zone_1
            solution_in_zones[random_zone_idx_2] = zone_2

            print("After swap1: ", solution_in_zones[random_zone_idx_1])
            print("After swap2: ", solution_in_zones[random_zone_idx_2])

        newParent = np.concatenate(solution_in_zones, axis=None)
        print("Big Bool: ", np.array_equal(newParent, parents[len(offspring)])) # Should be false
        print("Big Bool: ", len(newParent) == len(parents[len(offspring)])) # Should be true

        offspring.append(newParent)

    return np.array(offspring)


def switch_products(zone_1, zone_2, index_1, index_2, zone_1_slots, zone_2_slots):
    """
            Switches n number of elements from between the 2 zones
    """
    # Switch elements
    swap_1, swap_2 = check_constraints(zone_1, zone_2, index_1, index_2, zone_1_slots, zone_2_slots)

    if swap_1 is None or swap_2 is None:
        return zone_1, zone_2

    print("zone_1[swap_1]: ", zone_1[swap_1])
    print("zone_2[swap_2]: ", zone_2[swap_2])
    # Swap products
    temp = zone_1[swap_1]
    zone_1[swap_1] = zone_2[swap_2]
    zone_2[swap_2] = temp

    print("zone_1[swap_1]: ", zone_1[swap_1])
    print("zone_2[swap_2]: ", zone_2[swap_2])

    print("swap_1: ", swap_1)
    print("swap_2: ", swap_2)
    print("zone_1: ", zone_1)
    print("zone_2: ", zone_2)
    # return zones
    return zone_1, zone_2


def check_constraints(zone_1, zone_2, index_1, index_2, zone_1_slots, zone_2_slots):
    """
        Verifies if 2 elements can be switched of if a constraint is violated
    """
    product_1 = zone_1[index_1]
    product_2 = zone_2[index_2]

    # Get nbr of lanes
    if main.number_of_lanes.get(product_1) != main.number_of_lanes.get(product_2):
        return None, None

    constraints_products_db_tags_1, constraint_types_1 = get_constraint(product_1)
    constraints_products_db_tags_2, constraint_types_2 = get_constraint(product_2)

    # If a product has no contraints
    if has_constraint_in_array(constraint_types_1, constraint_types_2, Constraint.NONE):
        return index_1, index_2

    # If a product has a slot constraint
    if has_constraint_in_array(constraint_types_1, constraint_types_2, Constraint.SLOT):
        # One of the products has to be in this slot and cannot be swapped anywhere else
        return None, None

    # If a product has a level constraint
    if has_constraint_in_array(constraint_types_1, constraint_types_2, Constraint.LEVEL):
        index_1 = apply_level_constraints(constraints_products_db_tags_1, index_1, zone_2_slots)
        index_2 = apply_level_constraints(constraints_products_db_tags_2, index_2, zone_1_slots)
        if index_1 is None or index_2 is None:
            return None, None

    # If a product has a zone constraint
    if has_constraint_in_array(constraint_types_1, constraint_types_2, Constraint.ZONE):
        index_1 = apply_zone_constraints(constraints_products_db_tags_1, index_1, zone_2_slots)
        index_2 = apply_zone_constraints(constraints_products_db_tags_2, index_2, zone_1_slots)
        if index_1 is None or index_2 is None:
            return None, None

    # If a product has a side constraint
    if has_constraint_in_array(constraint_types_1, constraint_types_2, Constraint.SIDE):
        index_1 = apply_side_constraint(constraints_products_db_tags_1, index_1, zone_2_slots)
        index_2 = apply_side_constraint(constraints_products_db_tags_2, index_2, zone_1_slots)
        if index_1 is None or index_2 is None:
            return None, None

    return index_1, index_2


def has_constraint_in_array(constraints_products_1, constraints_products_2, con_type):
    return con_type in constraints_products_1 or con_type in constraints_products_2


def apply_level_constraints(constraints, index, target_slots):
    """
        This is only for the level constraint
        Verifies if the level to swap to is the allowed level for the product constraint
        None if constraint is violated
    """
    target_Level = str(target_slots[index][3])
    if target_Level in constraints:
        return index
    return None


def apply_zone_constraints(constraints, index, target_slots):
    """
        This is only for the zone constraint
        Verifies if the zone to swap to is in the allowed zones for the product constraint
        None if constraint is violated
    """
    target_zone = int(target_slots[index][:2])
    if target_zone in constraints:
        return index
    return None


def apply_type_constraint(constraints, index, target_slots):
    if main.location_type_constraints.get(target_slots) in constraints:
        return index
    return None


def apply_side_constraint(constraints, index, target_slots):
    if main.location_side_constraints.get(target_slots) in constraints:
        return index
    return None


def get_constraint(product):
    """
        Returns the constraints and identify the type
    """
    sku_constraint = main.constraints.get(product)
    constraint_types = []

    # Returns none if the constraints array is empty
    if sku_constraint is None:
        constraint_types.append(Constraint.NONE)
        return sku_constraint, constraint_types

    # Checks if the product has a slot constraint
    if check_regex_match('\d\d[A-D]\d\d', sku_constraint):
        constraint_types.append(Constraint.SLOT)

    # Checks if the product has a level constraint
    if check_regex_match('^[ABCD]$', sku_constraint):
        constraint_types.append(Constraint.LEVEL)

    # Checks if the product has a zone constraint
    if sku_constraint[0].isdigit():
        constraint_types.append(Constraint.ZONE)

    # Checks if the product has a location side constraint (EVEN/ODD)
    if "EVEN" in sku_constraint or "ODD" in sku_constraint:
        constraint_types.append(Constraint.SIDE)

    # Checks if the product has an Locationtype constraint ['FLOW' 'HIGHVALUE' 'WBS' 'WBSFLOW']
    if check_matching_strings(main.all_unique_location_types, sku_constraint):
        constraint_types.append(Constraint.TYPE)

    return sku_constraint, constraint_types


def check_regex_match(regex, to_match):
    # check with regex if constrains applies if so return true
    return len(list(filter(lambda v: match(regex, v), to_match))) >= 0


class Constraint(Enum):
    NONE = 1
    SLOT = 2
    ZONE = 3
    LEVEL = 4
    SIDE = 5
    TYPE = 6
